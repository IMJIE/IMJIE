//
//  ShoppingBtn.h
//  TDS
//
//  Created by 黎金 on 16/3/25.
//  Copyright © 2016年 sixgui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShoppingBtn : UIButton

@end
